import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Users, 
  Package, 
  ShoppingCart, 
  BarChart3, 
  FileText,
  X
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: Home },
  { name: "Clientes", href: "/customers", icon: Users },
  { name: "Produtos", href: "/products", icon: Package },
  { name: "Vendas", href: "/orders", icon: ShoppingCart },
  { name: "Financeiro", href: "/financial", icon: BarChart3 },
  { name: "Relatórios", href: "/reports", icon: FileText },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div
        className={cn(
          "bg-white w-64 shadow-lg flex-shrink-0 border-r border-gray-200 transition-transform duration-300 z-50",
          "fixed lg:static inset-y-0 left-0",
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-primary text-white rounded-lg p-2 mr-3">
                <BarChart3 className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">EmpresaGest</h1>
                <p className="text-sm text-gray-600">Sistema de Gestão</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="lg:hidden text-gray-400 hover:text-gray-600"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-6">
          <ul className="space-y-2 px-4">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href || (location === "/" && item.href === "/dashboard");
              
              return (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className={cn(
                      "nav-item",
                      isActive && "active"
                    )}
                    onClick={() => onClose()}
                  >
                    <Icon className="h-5 w-5 mr-3" />
                    <span>{item.name}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* User info */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center">
              <div className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-medium mr-3">
                <Users className="h-4 w-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">João Silva</p>
                <p className="text-xs text-gray-600">Administrador</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
