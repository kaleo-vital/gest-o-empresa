import { Users, DollarSign, Package, Clock, TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { DashboardStats } from "@shared/schema";
import { formatCurrency } from "@/lib/utils";

interface StatsCardsProps {
  stats?: DashboardStats;
}

export default function StatsCards({ stats }: StatsCardsProps) {
  if (!stats) return null;

  const cards = [
    {
      title: "Total de Clientes",
      value: stats.totalCustomers.toString(),
      change: `+${stats.salesGrowth}%`,
      trend: "up" as const,
      icon: Users,
      bgColor: "bg-blue-100",
      iconColor: "text-blue-600",
    },
    {
      title: "Vendas do Mês",
      value: formatCurrency(stats.monthlyRevenue),
      change: `+${stats.revenueGrowth}%`,
      trend: "up" as const,
      icon: DollarSign,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "Produtos Cadastrados",
      value: stats.totalProducts.toString(),
      change: `${stats.productsGrowth}%`,
      trend: stats.productsGrowth > 0 ? "up" : stats.productsGrowth < 0 ? "down" : "neutral",
      icon: Package,
      bgColor: "bg-orange-100",
      iconColor: "text-orange-600",
    },
    {
      title: "Pedidos Pendentes",
      value: stats.pendingOrders.toString(),
      change: "Atenção",
      trend: "warning" as const,
      icon: Clock,
      bgColor: "bg-red-100",
      iconColor: "text-red-600",
    },
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4" />;
      case "down":
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <Minus className="h-4 w-4" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "up":
        return "text-green-600";
      case "down":
        return "text-red-600";
      case "warning":
        return "text-red-600";
      default:
        return "text-yellow-600";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <div key={index} className="stats-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">{card.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{card.value}</p>
                <p className={`text-sm mt-1 flex items-center ${getTrendColor(card.trend)}`}>
                  {card.trend !== "warning" && getTrendIcon(card.trend)}
                  <span className="ml-1">{card.change}</span>
                </p>
              </div>
              <div className={`${card.bgColor} rounded-lg p-3`}>
                <Icon className={`${card.iconColor} h-6 w-6`} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
