import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
import { Skeleton } from "@/components/ui/skeleton";

Chart.register(...registerables);

interface CategoriesChartProps {
  data?: { category: string; count: number }[];
  isLoading: boolean;
}

export default function CategoriesChart({ data, isLoading }: CategoriesChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!data || isLoading || !canvasRef.current) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext("2d");
    if (!ctx) return;

    const colors = [
      "#3B82F6", // blue
      "#10B981", // green
      "#F59E0B", // yellow
      "#EF4444", // red
      "#8B5CF6", // purple
      "#06B6D4", // cyan
    ];

    chartRef.current = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: data.map(item => item.category),
        datasets: [
          {
            data: data.map(item => item.count),
            backgroundColor: colors.slice(0, data.length),
            borderWidth: 0,
            hoverOffset: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              padding: 20,
              usePointStyle: true,
              pointStyle: "circle",
            },
          },
        },
        cutout: "60%",
      },
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data, isLoading]);

  if (isLoading) {
    return (
      <div className="chart-container">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Categorias de Produtos</h3>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="chart-container">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Categorias de Produtos</h3>
      <div className="h-64">
        <canvas ref={canvasRef} />
      </div>
    </div>
  );
}
