import { UserPlus, ShoppingCart, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { RecentActivity as ActivityType } from "@shared/schema";

interface RecentActivityProps {
  data?: ActivityType[];
  isLoading: boolean;
}

export default function RecentActivity({ data, isLoading }: RecentActivityProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case "customer":
        return UserPlus;
      case "order":
        return ShoppingCart;
      case "product":
        return AlertTriangle;
      default:
        return AlertTriangle;
    }
  };

  const getIconColor = (color: string) => {
    switch (color) {
      case "green":
        return "bg-green-100 text-green-600";
      case "blue":
        return "bg-blue-100 text-blue-600";
      case "orange":
        return "bg-orange-100 text-orange-600";
      case "red":
        return "bg-red-100 text-red-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Atividades Recentes</h3>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center">
                <Skeleton className="h-8 w-8 rounded-full mr-4" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Atividades Recentes</h3>
        </div>
        <div className="p-6">
          <p className="text-gray-500 text-center">Nenhuma atividade recente encontrada.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Atividades Recentes</h3>
      </div>
      <div className="p-6">
        <div className="space-y-4">
          {data.map((activity) => {
            const Icon = getIcon(activity.type);
            return (
              <div key={activity.id} className="flex items-center">
                <div className={`rounded-full p-2 mr-4 ${getIconColor(activity.color)}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                  <p className="text-xs text-gray-600">{activity.time}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
