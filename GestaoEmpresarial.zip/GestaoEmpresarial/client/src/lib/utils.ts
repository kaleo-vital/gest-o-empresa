import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(value: number | string): string {
  const numValue = typeof value === "string" ? parseFloat(value) : value;
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(numValue);
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

export function getStatusColor(status: string): string {
  const statusColors: { [key: string]: string } = {
    active: "bg-green-100 text-green-700",
    inactive: "bg-gray-100 text-gray-700",
    pending: "bg-yellow-100 text-yellow-700",
    completed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    low_stock: "bg-orange-100 text-orange-700",
    out_of_stock: "bg-red-100 text-red-700",
  };
  return statusColors[status] || "bg-gray-100 text-gray-700";
}

export function getStatusLabel(status: string): string {
  const statusLabels: { [key: string]: string } = {
    active: "Ativo",
    inactive: "Inativo",
    pending: "Pendente",
    completed: "Finalizado",
    cancelled: "Cancelado",
    low_stock: "Estoque Baixo",
    out_of_stock: "Sem Estoque",
  };
  return statusLabels[status] || status;
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map(word => word.charAt(0))
    .join("")
    .toUpperCase()
    .slice(0, 2);
}
