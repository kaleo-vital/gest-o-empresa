import { Users, BarChart3, Package, DollarSign, PieChart, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Reports() {
  const { toast } = useToast();

  const handleGenerateReport = (reportType: string) => {
    toast({
      title: "Relatório em processamento",
      description: `Gerando relatório de ${reportType}...`,
    });
  };

  const reports = [
    {
      title: "Relatório de Clientes",
      description: "Análise completa da base de clientes, incluindo novos cadastros e atividade.",
      icon: Users,
      bgColor: "bg-blue-100",
      iconColor: "text-blue-600",
      buttonColor: "bg-blue-600 hover:bg-blue-700",
      type: "clientes"
    },
    {
      title: "Relatório de Vendas",
      description: "Análise detalhada das vendas por período, produtos e vendedores.",
      icon: BarChart3,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
      buttonColor: "bg-green-600 hover:bg-green-700",
      type: "vendas"
    },
    {
      title: "Relatório de Estoque",
      description: "Controle de inventário, produtos em falta e movimentação.",
      icon: Package,
      bgColor: "bg-orange-100",
      iconColor: "text-orange-600",
      buttonColor: "bg-orange-600 hover:bg-orange-700",
      type: "estoque"
    },
    {
      title: "Relatório Financeiro",
      description: "DRE, fluxo de caixa e análise de lucratividade.",
      icon: DollarSign,
      bgColor: "bg-purple-100",
      iconColor: "text-purple-600",
      buttonColor: "bg-purple-600 hover:bg-purple-700",
      type: "financeiro"
    },
    {
      title: "Relatório Analítico",
      description: "Análise de performance e KPIs do negócio.",
      icon: PieChart,
      bgColor: "bg-red-100",
      iconColor: "text-red-600",
      buttonColor: "bg-red-600 hover:bg-red-700",
      type: "analítico"
    },
    {
      title: "Relatório Personalizado",
      description: "Crie relatórios customizados com os dados que você precisa.",
      icon: Settings,
      bgColor: "bg-gray-100",
      iconColor: "text-gray-600",
      buttonColor: "bg-gray-600 hover:bg-gray-700",
      type: "personalizado"
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report, index) => {
          const Icon = report.icon;
          return (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`${report.bgColor} rounded-lg p-3`}>
                  <Icon className={`${report.iconColor} h-6 w-6`} />
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-400 hover:text-gray-600"
                  onClick={() => handleGenerateReport(report.type)}
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </Button>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{report.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{report.description}</p>
              <Button
                className={`w-full ${report.buttonColor} text-white transition-colors`}
                onClick={() => handleGenerateReport(report.type)}
              >
                Gerar Relatório
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
