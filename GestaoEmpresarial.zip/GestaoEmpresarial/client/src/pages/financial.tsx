import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
import { TrendingUp, TrendingDown, BarChart3 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";

Chart.register(...registerables);

export default function Financial() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  const { data: financialData, isLoading } = useQuery({
    queryKey: ["/api/dashboard/financial-data"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  useEffect(() => {
    if (!financialData || isLoading || !canvasRef.current) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext("2d");
    if (!ctx) return;

    chartRef.current = new Chart(ctx, {
      type: "bar",
      data: {
        labels: financialData.map((item: any) => item.month),
        datasets: [
          {
            label: "Receitas",
            data: financialData.map((item: any) => item.revenue),
            backgroundColor: "#10B981",
            borderRadius: 4,
            barThickness: 40,
          },
          {
            label: "Despesas",
            data: financialData.map((item: any) => item.expenses),
            backgroundColor: "#EF4444",
            borderRadius: 4,
            barThickness: 40,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "top",
            align: "end",
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: {
              color: "#f1f5f9",
            },
            ticks: {
              callback: function(value) {
                return new Intl.NumberFormat("pt-BR", {
                  style: "currency",
                  currency: "BRL",
                  minimumFractionDigits: 0,
                }).format(value as number);
              },
            },
          },
          x: {
            grid: {
              display: false,
            },
          },
        },
      },
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [financialData, isLoading]);

  // Calculate financial metrics
  const totalRevenue = financialData?.reduce((sum: number, item: any) => sum + item.revenue, 0) || 0;
  const totalExpenses = financialData?.reduce((sum: number, item: any) => sum + item.expenses, 0) || 0;
  const netProfit = totalRevenue - totalExpenses;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Receita Total</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatCurrency(totalRevenue)}
              </p>
              <p className="text-green-600 text-sm mt-1 flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" />
                <span>+15% vs mês anterior</span>
              </p>
            </div>
            <div className="bg-green-100 rounded-lg p-3">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Despesas</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatCurrency(totalExpenses)}
              </p>
              <p className="text-red-600 text-sm mt-1 flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" />
                <span>+5% vs mês anterior</span>
              </p>
            </div>
            <div className="bg-red-100 rounded-lg p-3">
              <TrendingDown className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Lucro Líquido</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatCurrency(netProfit)}
              </p>
              <p className="text-green-600 text-sm mt-1 flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" />
                <span>+22% vs mês anterior</span>
              </p>
            </div>
            <div className="bg-blue-100 rounded-lg p-3">
              <BarChart3 className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Financial Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Fluxo Financeiro</h3>
        </div>
        <div className="p-6">
          <div className="h-96">
            <canvas ref={canvasRef} />
          </div>
        </div>
      </div>
    </div>
  );
}
